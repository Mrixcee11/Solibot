package com.example.solibot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bot", Context.MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "SoliBot"
        title.textSize = 28f

        status = TextView(this)
        status.textSize = 15f
        status.setPadding(0, pad / 2, 0, pad / 2)

        val keyBox = EditText(this)
        keyBox.hint = "Gemini API-Key (einmalig)"
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyBox.setText(prefs.getString("key", ""))

        val setup = Button(this)
        setup.text = "1) Bedienungshilfe aktivieren (einmalig)"
        setup.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val start = Button(this)
        start.text = "START"
        start.textSize = 26f
        start.setOnClickListener {
            val key = keyBox.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "Bitte API-Key eintragen", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            prefs.edit().putString("key", key).apply()
            val svc = BotService.instance
            if (svc == null) {
                Toast.makeText(this, "Bitte zuerst SoliBot in den Bedienungshilfen aktivieren", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            launchGame()
            svc.startBot()
        }

        val info = TextView(this)
        info.textSize = 13f
        info.setPadding(0, pad, 0, 0)
        info.text = "Ablauf: Key eintragen, Bedienungshilfe aktivieren (Android 13+: vorher in den App-Infos " +
            "'Eingeschraenkte Einstellungen zulassen'), dann START. Die App startet das Spiel und spielt automatisch. " +
            "Stoppen: Knopf oben in der Mitte des Bildschirms."

        root.addView(title)
        root.addView(status)
        root.addView(keyBox)
        root.addView(setup)
        root.addView(start)
        root.addView(info)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (BotService.instance != null) "Bedienungshilfe: aktiv" else "Bedienungshilfe: NICHT aktiv"
    }

    private fun launchGame() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0).filter { it.activityInfo.packageName != packageName }
        val hit = apps.firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            l.contains("disney") && l.contains("solitaire")
        } ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains("solitaire") }
        val launch = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Spiel nicht gefunden - bitte selbst oeffnen", Toast.LENGTH_LONG).show()
        }
    }
}
