package com.example.solibot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

private val PROMPT = """This is a screenshot of the mobile game Disney Solitaire (TriPeaks style): cards lie in stacks on the table, some face-down (blue backs) and some face-up. The player may play a face-up table card whose rank is exactly one higher or lower than the card on the waste pile (suit does not matter). The face-down draw pile (stock) at the bottom turns a new card onto the waste pile.
Return ONLY JSON:
{"screen":"game|map|dialog|popup|other",
 "board":[{"rank":"A|2|3|4|5|6|7|8|9|10|J|Q|K","box":[ymin,xmin,ymax,xmax]}],
 "waste":{"rank":"..","box":[ymin,xmin,ymax,xmax]},
 "stock":{"box":[ymin,xmin,ymax,xmax],"empty":false},
 "button":{"label":"text on the button","box":[ymin,xmin,ymax,xmax],"costs":false}}
Rules:
- Boxes are normalized 0-1000 relative to the image (ymin,xmin,ymax,xmax).
- screen "game": the card table with a draw pile. "map": the world map with a big green LEVEL button. "dialog": the level start dialog with a green STARTEN/START button. "popup": any other window (level complete, level failed, rewards, offers).
- "board": ONLY face-up cards (showing a rank) lying on the table stacks. Exclude face-down backs, the waste card, and every booster or UI element (WILD card, +1 card, buttons, coin counters).
- "waste": the single face-up card next to the draw pile at the bottom. "stock": the face-down draw pile; empty=true when no cards are left.
- If screen is not "game": board is [] and "button" is the one button that moves the player forward: on "map" the green LEVEL button, on "dialog" the green STARTEN/START button, on "popup" a Continue/Weiter/OK/Collect/Einsammeln button, otherwise the close X. Set "costs":true if the button needs coins, gems, money or watching an ad (it shows a price or a video symbol). Never pick the plus/minus buttons, shop, offers or purchase buttons. Use null if there is no safe button.
- In a "game" screen "button" is null.
Output JSON only, no extra text."""

private data class Card(val rank: Int, val x: Float, val y: Float)

class BotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BotService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val shotExecutor = Executors.newSingleThreadExecutor()
    private var overlay: Button? = null

    @Volatile
    private var running = false
    private var modelIdx = 0
    private var lastCall = 0L

    private val models = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite")
    private val ranks = mapOf("A" to 1, "J" to 11, "Q" to 12, "K" to 13, "10" to 10) +
        (2..9).associate { it.toString() to it }
    private val blocked = listOf("kauf", "buy", "shop", "werbung", "video", "angebot", "offer", "gem", "spin", "+", "premium", "gratis")
    private val allowed = listOf("start", "level", "weiter", "continue", "next", "ok", "collect", "einsammeln", "abholen", "claim", "spiel", "play", "close", "schlie", "fertig", "tippe", "tap")

    // ---------- Lebenszyklus ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        instance = null
        removeOverlay()
        return super.onUnbind(intent)
    }

    // ---------- Overlay (Start/Stop) ----------
    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this)
        b.textSize = 12f
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.argb(210, 40, 40, 40))
        b.keepScreenOn = true
        b.setOnClickListener { if (running) stopBot() else startBot() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        wm.addView(b, lp)
        overlay = b
        updateOverlay()
    }

    private fun removeOverlay() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        overlay = null
    }

    private fun updateOverlay() {
        main.post { overlay?.text = if (running) "■ STOP" else "▶ START" }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    // ---------- Start/Stop ----------
    fun startBot() {
        if (running) return
        val key = getSharedPreferences("bot", MODE_PRIVATE).getString("key", "")?.trim() ?: ""
        if (key.isEmpty()) {
            toast("Bitte erst in der SoliBot-App den API-Key eintragen")
            return
        }
        running = true
        updateOverlay()
        thread(start = true, name = "solibot") {
            try {
                loop(key)
            } catch (e: Exception) {
                toast("Fehler: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                running = false
                updateOverlay()
                toast("SoliBot beendet")
            }
        }
    }

    fun stopBot() {
        running = false
        updateOverlay()
    }

    // ---------- Screenshot und Gesten ----------
    private fun screenshot(): Bitmap? {
        var result: Bitmap? = null
        val latch = CountDownLatch(1)
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        result = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } finally {
                        r.hardwareBuffer.close()
                        latch.countDown()
                    }
                }

                override fun onFailure(errorCode: Int) {
                    latch.countDown()
                }
            })
        } catch (e: Exception) {
            return null
        }
        latch.await(6, TimeUnit.SECONDS)
        return result
    }

    private fun tapAt(x: Float, y: Float) {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        latch.await(3, TimeUnit.SECONDS)
    }

    // ---------- Gemini ----------
    private fun parseJson(text: String): JSONObject? {
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        if (a < 0 || b < a) return null
        return try {
            JSONObject(text.substring(a, b + 1))
        } catch (e: JSONException) {
            null
        }
    }

    private fun askGemini(bmp: Bitmap, key: String): JSONObject? {
        val w = 768
        val h = bmp.height * w / bmp.width
        val small = Bitmap.createScaledBitmap(bmp, w, h, true)
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 80, out)
        small.recycle()
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", PROMPT))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0).put("responseMimeType", "application/json"))
            .toString()

        for (attempt in 0 until 6) {
            if (!running) return null
            val wait = 4500 - (System.currentTimeMillis() - lastCall)
            if (wait > 0) Thread.sleep(wait)
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${models[modelIdx]}:generateContent")
            lastCall = System.currentTimeMillis()
            val c = url.openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                if (code == 200) {
                    val txt = c.inputStream.bufferedReader().readText()
                    val ps = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
                    val res = parseJson(sb.toString())
                    if (res != null) return res
                } else {
                    val err = c.errorStream?.bufferedReader()?.readText() ?: ""
                    if ((code == 400 || code == 401 || code == 403) && err.contains("key", ignoreCase = true)) {
                        toast("API-Key abgelehnt")
                        running = false
                        return null
                    } else if (code == 404 || (code == 429 && err.contains("limit: 0"))) {
                        modelIdx++
                        if (modelIdx >= models.size) {
                            toast("Kein Gemini-Modell verfuegbar (Kontingent/Modellnamen pruefen)")
                            running = false
                            return null
                        }
                    } else if (code == 429 || code == 500 || code == 503) {
                        Thread.sleep(10000L * (attempt + 1))
                    } else {
                        toast("API-Fehler $code")
                        running = false
                        return null
                    }
                }
            } catch (e: IOException) {
                Thread.sleep(3000)
            } catch (e: JSONException) {
                Thread.sleep(2000)
            } finally {
                c.disconnect()
            }
        }
        return null
    }

    // ---------- Hilfsfunktionen ----------
    private fun center(a: JSONArray?, w: Int, h: Int): Pair<Float, Float>? {
        if (a == null || a.length() != 4) return null
        val v = DoubleArray(4) { a.optDouble(it, Double.NaN) }
        if (v.any { it.isNaN() }) return null
        return Pair(((v[1] + v[3]) / 2000.0 * w).toFloat(), ((v[0] + v[2]) / 2000.0 * h).toFloat())
    }

    private fun adj(a: Int, b: Int, wrap: Boolean): Boolean {
        val d = Math.abs(a - b)
        return d == 1 || (wrap && d == 12)
    }

    private fun bestChain(rs: List<Int>, top: Int, wrap: Boolean): List<Int> {
        var calls = 0
        fun dfs(used: Int, cur: Int): List<Int> {
            calls++
            var best = emptyList<Int>()
            if (calls > 30000) return best
            for (i in rs.indices) {
                if (((used shr i) and 1) == 0 && adj(rs[i], cur, wrap)) {
                    val p = listOf(i) + dfs(used or (1 shl i), rs[i])
                    if (p.size > best.size) best = p
                }
            }
            return best
        }
        return dfs(0, top).take(8)
    }

    private fun buttonOk(label: String): Boolean {
        val l = label.lowercase()
        if (blocked.any { l.contains(it) }) return false
        return l == "x" || l == "✕" || allowed.any { l.contains(it) }
    }

    // ---------- Hauptschleife ----------
    private fun loop(key: String) {
        var lastSig = ""
        var same = 0
        var fails = 0
        var nonGame = 0
        var wrapOk = true
        var lastWrap = false
        Thread.sleep(5000)
        while (running) {
            val bmp = screenshot()
            if (bmp == null) {
                fails++
                if (fails > 20) {
                    toast("Screenshot nicht moeglich (Bedienungshilfe pruefen)")
                    return
                }
                Thread.sleep(1000)
                continue
            }
            val w = bmp.width
            val h = bmp.height
            val d = askGemini(bmp, key)
            bmp.recycle()
            if (!running) return
            if (d == null) {
                fails++
                if (fails > 6) {
                    toast("Keine brauchbare Antwort von Gemini")
                    return
                }
                continue
            }
            fails = 0

            if (d.optString("screen") != "game") {
                nonGame++
                if (nonGame > 25) {
                    toast("Bot haengt in Menues - bitte selbst bedienen")
                    return
                }
                val b = d.optJSONObject("button")
                val label = b?.optString("label", "")?.trim() ?: ""
                val pos = center(b?.optJSONArray("box"), w, h)
                val costs = b?.optBoolean("costs", false) ?: false
                if (b != null && pos != null && (costs || !buttonOk(label))) {
                    if (nonGame > 3) {
                        toast("Kein sicherer Button ('$label') - bitte selbst bedienen")
                        return
                    }
                    Thread.sleep(2500)
                    continue
                }
                if (b == null || pos == null) {
                    Thread.sleep(2500)
                    continue
                }
                tapAt(pos.first, pos.second)
                Thread.sleep(2500)
                continue
            }
            nonGame = 0

            val board = ArrayList<Card>()
            val arr = d.optJSONArray("board")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val r = ranks[o.optString("rank").uppercase().trim()]
                    val c = center(o.optJSONArray("box"), w, h)
                    if (r != null && c != null && board.size < 30) board.add(Card(r, c.first, c.second))
                }
            }
            val wo = d.optJSONObject("waste")
            val waste = if (wo != null) ranks[wo.optString("rank").uppercase().trim()] else null
            val so = d.optJSONObject("stock")
            val stockPos = center(so?.optJSONArray("box"), w, h)
            val stockEmpty = so?.optBoolean("empty", false) ?: false

            if (waste == null) {
                same++
                if (same >= 6) {
                    toast("Ablagekarte nicht erkannt - Ende")
                    return
                }
                Thread.sleep(1500)
                continue
            }

            val rs = board.map { it.rank }
            val sig = rs.sorted().joinToString(",") + "|" + waste
            if (sig == lastSig) {
                same++
                if (lastWrap && same == 1) wrapOk = false
            } else {
                same = 0
            }
            lastSig = sig
            if (same >= 6) {
                toast("Keine Veraenderung mehr - Ende")
                return
            }

            var chain = bestChain(rs, waste, false)
            var usingWrap = false
            if (chain.isEmpty() && wrapOk) {
                chain = bestChain(rs, waste, true)
                usingWrap = chain.isNotEmpty()
            }
            lastWrap = usingWrap

            if (chain.isNotEmpty()) {
                for (i in chain) {
                    if (!running) return
                    tapAt(board[i].x, board[i].y)
                    Thread.sleep(550)
                }
            } else if (stockPos != null && !stockEmpty) {
                tapAt(stockPos.first, stockPos.second)
            } else {
                Thread.sleep(2500)
            }
            Thread.sleep(1200)
        }
    }
}
